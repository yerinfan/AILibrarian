package com.example.app_test;

import androidx.appcompat.app.AlertDialog;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ImageAdapter imageAdapter;
    private List<File> imageFiles = new ArrayList<>();
    private ActivityResultLauncher<Intent> imagePickerLauncher;

    private static final String TAG = "MainActivity"; // 로그 태그 설정

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 로그: onCreate 시작
        Log.d(TAG, "onCreate: 시작");

        // RecyclerView 초기화
        recyclerView = findViewById(R.id.recyclerView);
        Button btnSelectImage = findViewById(R.id.btnSelectImage);

        // 권한 요청 및 확인
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // 로그: 권한 요청
            Log.d(TAG, "권한 없음, 요청 중...");
            // 권한이 없으면 요청
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        } else {
            // 로그: 권한 이미 허용됨
            Log.d(TAG, "권한 이미 허용됨, 이미지 불러오기");
            // 권한이 이미 허용된 경우 바로 이미지 불러오기
            loadImagesFromStorage();
        }

        // RecyclerView 설정 (리스트 형태로 이미지 표시)
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        imageAdapter = new ImageAdapter(imageFiles);
        recyclerView.setAdapter(imageAdapter);

        imageAdapter.setOnItemClickListener(file -> {
            showFunctionDialog(file);
        });

        // 사진 선택 후 결과 처리
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        saveImageToStorage(imageUri);  // 선택한 이미지를 저장
                    }
                }
        );

        // 사진 선택 버튼 클릭 시 갤러리 열기
        btnSelectImage.setOnClickListener(v -> openGallery());

        // 저장된 이미지 목록 불러오기
        loadImagesFromStorage();
    }

    // 갤러리 열기
    private void openGallery() {
        // 로그: 갤러리 열기
        Log.d(TAG, "openGallery: 갤러리 열기");

        // 갤러리에서 이미지를 선택할 수 있도록 설정
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*"); // 이미지 파일만 선택하도록 설정
        imagePickerLauncher.launch(intent); // 갤러리 열기
    }

    // 선택한 이미지를 내부 저장소(UserImg 폴더)에 저장
    private void saveImageToStorage(Uri imageUri) {
        Log.d(TAG, "saveImageToStorage: 이미지 저장 시작");

        try {
            // 저장될 디렉토리 경로 설정
            File directory = new File(getExternalFilesDir(null), "UserImg");
            if (!directory.exists()) {
                directory.mkdirs(); // 디렉토리가 없다면 생성
            }

            // 예시용 UserId (실제 앱에선 사용자마다 다르게 설정해야 함)
            String userId = "UserTest"; // TODO: 사용자 ID에 맞게 변경 가능

            // 시간 기반 파일 이름 생성
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());

            // 변경된 파일명 형식 적용
            String fileName = userId + "_RawImg_" + timeStamp + ".jpg";

            File file = new File(directory, fileName);

            // 이미지 저장
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            FileOutputStream outputStream = new FileOutputStream(file);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();

            Log.d(TAG, "이미지 저장 성공: " + file.getAbsolutePath());
            Toast.makeText(this, "사진이 저장되었습니다.", Toast.LENGTH_SHORT).show();

            loadImagesFromStorage();

        } catch (Exception e) {
            Log.e(TAG, "사진 저장 실패", e);
            Toast.makeText(this, "사진 저장 실패", Toast.LENGTH_SHORT).show();
        }
    }


    // 저장된 이미지 목록을 불러오기
    private void loadImagesFromStorage() {
        // 로그: 이미지 목록 불러오기
        Log.d(TAG, "loadImagesFromStorage: 이미지 목록 불러오기");

        // 이미지 목록을 비우고 새로 불러오기
        imageFiles.clear();
        File directory = new File(getExternalFilesDir(null), "UserImg");
        if (directory.exists()) {
            // 디렉토리가 존재하면 해당 파일들을 불러옴
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    imageFiles.add(file); // 리스트에 파일 추가
                }
            }
        }
        // 이미지 리스트 갱신을 위해 Adapter에 알리기
        imageAdapter.notifyDataSetChanged();
    }

    // 권한 요청 결과 처리
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 로그: 권한 허용됨
                Log.d(TAG, "권한 허용됨, 이미지 목록 불러오기");
                // 권한이 허용되면 이미지 목록 불러오기
                loadImagesFromStorage();
            } else {
                // 로그: 권한 거부됨
                Log.d(TAG, "권한 거부됨, 사용자에게 알림");
                // 권한이 거부되면 사용자에게 알림
                Toast.makeText(this, "권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void processImage(File originalFile, String targetFolderName) {
        try {
            File targetDir = new File(getExternalFilesDir(null), targetFolderName);
            if (!targetDir.exists()) {
                targetDir.mkdirs();
            }

            String originalName = originalFile.getName(); // 예: IMG_20250324_044134.jpg

            // ✅ 중복 가공 방지: 접미사 제거
            if (originalName.endsWith("_Text.jpg")) {
                originalName = originalName.replace("_Text.jpg", ".jpg");
            } else if (originalName.endsWith("_Guide.jpg")) {
                originalName = originalName.replace("_Guide.jpg", ".jpg");
            }

            // 확장자 제거
            String baseName = originalName.substring(0, originalName.lastIndexOf(".")); // IMG_20250324_044134

            // 기능에 따라 접미사 결정
            String suffix = targetFolderName.equals("UserGuide") ? "_Guide.jpg" : "_Text.jpg";
            String newFileName = baseName + suffix;

            File newFile = new File(targetDir, newFileName);

            // ✅ 이미 존재하면 덮어쓰기 없이 바로 화면 전환
            if (newFile.exists()) {
                Log.d(TAG, "이미 가공된 파일 존재: " + newFile.getAbsolutePath());
                Toast.makeText(this, "이미 가공된 이미지입니다.", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(this, ProcessedImageActivity.class);
                intent.putExtra("singleFilePath", newFile.getAbsolutePath());
                startActivity(intent);
                return;
            }

            // ✅ 복사 실행
            InputStream inputStream = getContentResolver().openInputStream(Uri.fromFile(originalFile));
            FileOutputStream outputStream = new FileOutputStream(newFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }
            inputStream.close();
            outputStream.close();

            Toast.makeText(this, "가공된 이미지가 저장되었습니다.", Toast.LENGTH_SHORT).show();

            // 화면 전환
            Intent intent = new Intent(this, ProcessedImageActivity.class);
            intent.putExtra("singleFilePath", newFile.getAbsolutePath());
            startActivity(intent);

        } catch (Exception e) {
            Log.e(TAG, "이미지 가공 중 오류", e);
            Toast.makeText(this, "이미지 가공 실패", Toast.LENGTH_SHORT).show();
        }
    }



    //기능 선택 다이얼로그 추가
    private void showFunctionDialog(File imageFile) {
        new AlertDialog.Builder(this)
                .setTitle("기능 선택")
                .setMessage("어떤 기능을 사용하시겠습니까?")
                .setPositiveButton("책장 정리", (dialog, which) -> {
                    processImage(imageFile, "UserGuide");
                })
                .setNegativeButton("책 제목 추출", (dialog, which) -> {
                    processImage(imageFile, "UserText");
                })
                .setNeutralButton("취소", null)
                .show();
    }


}
