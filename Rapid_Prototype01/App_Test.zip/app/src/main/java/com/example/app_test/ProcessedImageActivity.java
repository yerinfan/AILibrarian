package com.example.app_test;

import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class ProcessedImageActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ImageAdapter imageAdapter;
    private List<File> imageFiles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_processed_image);

        recyclerView = findViewById(R.id.recyclerViewProcessed);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        imageAdapter = new ImageAdapter(imageFiles);
        recyclerView.setAdapter(imageAdapter);

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        // 👉 하나의 가공 이미지 경로 받아서 표시
        String singlePath = getIntent().getStringExtra("singleFilePath");
        if (singlePath != null) {
            File singleFile = new File(singlePath);
            if (singleFile.exists()) {
                imageFiles.clear();
                imageFiles.add(singleFile);
                imageAdapter.notifyDataSetChanged();
                return;
            }
        }

        // 혹시라도 폴더 전체 불러오는 경우 대비 (선택 사항)
        String folderName = getIntent().getStringExtra("folder");
        if (folderName != null) {
            loadImagesFrom(folderName);
        }
    }

    private void loadImagesFrom(String folderName) {
        imageFiles.clear();
        File directory = new File(getExternalFilesDir(null), folderName);
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    imageFiles.add(file);
                }
            }
        }
        imageAdapter.notifyDataSetChanged();
    }
}

